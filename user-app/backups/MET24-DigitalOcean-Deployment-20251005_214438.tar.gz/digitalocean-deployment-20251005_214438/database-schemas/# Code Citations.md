# Code Citations

## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
```


## License: unknown
https://github.com/aallali/N-Puzzle-Js/blob/4b2ede39e895f53e459043e77f4ca8dbc63305af/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:
```


## License: unknown
https://github.com/aallali/N-Puzzle-Js/blob/4b2ede39e895f53e459043e77f4ca8dbc63305af/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1
```


## License: unknown
https://github.com/aallali/N-Puzzle-Js/blob/4b2ede39e895f53e459043e77f4ca8dbc63305af/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
```


## License: unknown
https://github.com/aallali/N-Puzzle-Js/blob/4b2ede39e895f53e459043e77f4ca8dbc63305af/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│
```


## License: unknown
https://github.com/aallali/N-Puzzle-Js/blob/4b2ede39e895f53e459043e77f4ca8dbc63305af/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!
```


## License: unknown
https://github.com/aallali/N-Puzzle-Js/blob/4b2ede39e895f53e459043e77f4ca8dbc63305af/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  
```


## License: unknown
https://github.com/aallali/N-Puzzle-Js/blob/4b2ede39e895f53e459043e77f4ca8dbc63305af/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└──────────────────
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└──────────────────
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└──────────────────
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└──────────────────
```


## License: unknown
https://github.com/aallali/N-Puzzle-Js/blob/4b2ede39e895f53e459043e77f4ca8dbc63305af/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└──────────────────
```


## License: unknown
https://github.com/garbados/omgcolors/blob/8308cb06aaa4037b570f95572bd76c95eee74002/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└─────────────────────────────────────────────
```


## License: unknown
https://github.com/ryotakato/ryotakato.github.io/blob/20415f2ec5c97890e20bca0ab50fe079047ca6d4/_posts/2023-11-22-install-node-by-asdf.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└─────────────────────────────────────────────
```


## License: Apache-2.0
https://github.com/nashville-software-school/client-side-mastery/blob/b1689e2b67b32f907c02050be9d0a1967c848a20/book-2-martins-aquarium/chapters/COFFEE_HOUSES.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└─────────────────────────────────────────────
```


## License: unknown
https://github.com/LuckyGStar/Javascript-Image-Zoom/blob/7c8b0a28f03a1cdb6ae12558523cf8e1db103170/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└─────────────────────────────────────────────
```


## License: unknown
https://github.com/aallali/N-Puzzle-Js/blob/4b2ede39e895f53e459043e77f4ca8dbc63305af/README.md

```
─────────────────────────────────────────┐
│                                                  │
│   Serving!                                       │
│                                                  │
│   - Local:            http://localhost:3000      │
│   - On Your Network:  http://192.168.1.x:3000   │
│                                                  │
│   Copied local address to clipboard!             │
│                                                  │
└─────────────────────────────────────────────
```

