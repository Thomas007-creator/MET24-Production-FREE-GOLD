class BaseAdapter {
  async callModel(kind, prompt, params) {
    throw new Error('Not implemented');
  }
}

module.exports = BaseAdapter;
















